﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace W8
{
    public partial class Form1 : Form
    {
        public string connectionString;
        public MySqlConnection sqlConnect;
        public string sqlQuery;
        public MySqlCommand sqlCommand;
        public MySqlDataAdapter sqlAdapter;
        public DataTable dtPemain = new DataTable();
        public DataTable dtTeam = new DataTable();
        public DataTable dtNationality = new DataTable();
        public DataTable dtMatch = new DataTable();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Connection
            connectionString = "server=localhost;port=3366;user id=root;password=;database=premier_league;";

            // MYsqlConnection object

            //team table
            sqlConnect = new MySqlConnection(connectionString);
            sqlQuery = "SELECT t.`team_name`, t.`team_id` FROM premier_league.team t";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dtTeam);

            menuStrip1.Items.Clear();

            ToolStripMenuItem menuDataPemain = new ToolStripMenuItem("Player Data");

            foreach (DataRow row in dtTeam.Rows)
            {
                ToolStripMenuItem menuBaru = new ToolStripMenuItem();
                menuBaru.Name = row[0].ToString();
                menuBaru.Text = row[0].ToString();
                menuBaru.Click += new EventHandler(menuBaru_Click);
                menuDataPemain.DropDownItems.Add(menuBaru);

            }

            menuStrip1.Items.Add(menuDataPemain);

            ToolStripMenuItem menuDataPertandingan = new ToolStripMenuItem("Match Detail");

            foreach (DataRow row in dtTeam.Rows)
            {
                ToolStripMenuItem menuBaru = new ToolStripMenuItem();
                menuBaru.Name = row[0].ToString();
                menuBaru.Text = row[0].ToString();
                menuBaru.Click += new EventHandler(menuBaruDataPertandingan_Click);
                menuDataPertandingan.DropDownItems.Add(menuBaru);

            }

            menuStrip1.Items.Add(menuDataPertandingan);

        }
        private void menuBaru_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem clickedMenu = (ToolStripMenuItem)sender;




            //table pemain

            sqlQuery = sqlQuery = "SELECT player_name, team_name, playing_pos, nation,type FROM premier_league.player p, premier_league.team t, premier_league.nationality n, premier_league.dmatch d WHERE p.team_id = t.team_id AND p.nationality_id = n.nationality_id AND p.player_id = d.player_id AND t.team_name = \"" + clickedMenu.Text + "\";"; 
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            dtPemain.Clear();
            sqlAdapter.Fill(dtPemain);

            menuStrip1.Items.Clear();

            //Make Combobox
            this.panel1.Controls.Clear();
            // Create a new Combo control
            System.Windows.Forms.ComboBox comboPemain = new System.Windows.Forms.ComboBox();

            // Set the properties of the textbox
            comboPemain.Name = "comboPemain";

            comboPemain.Location = new Point(50, 50);
            comboPemain.Size = new Size(200, 50);
            comboPemain.SelectedIndexChanged += new EventHandler(comboBoxPemain_SelectedIndexChanged);

            this.panel1.Controls.Add(comboPemain);

            //Membuat Pemain Unik
            List<string> listPemainUnik = new List<string>();
            foreach (DataRow row in dtPemain.Rows)
            {
                listPemainUnik.Add(row[0].ToString());

            }

            List<string> uniqueListPemain = listPemainUnik.Distinct().ToList();
            foreach (string item in uniqueListPemain)
            {
                comboPemain.Items.Add(item);
            }



            
        }

        private void menuBaruDataPertandingan_Click (object sender, EventArgs e)
        {
            ToolStripMenuItem clickedMenu = (ToolStripMenuItem)sender;




            //table matchhhh

            sqlQuery = sqlQuery = sqlQuery = "SELECT match_date,minute,team_name,team_home,team_away,player_name,type FROM premier_league.`match` m, premier_league.team t, premier_league.dmatch dm,premier_league.player p WHERE m.match_id=dm.match_id AND p.player_id=dm.player_id AND t.team_id=dm.team_id AND(m.team_home =t.team_id OR m.team_away=t.team_id) AND t.team_name= \"" + clickedMenu.Text + "\";";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            dtMatch.Clear();
            sqlAdapter.Fill(dtMatch);

            menuStrip1.Items.Clear();

            //Make Combobox
            this.panel1.Controls.Clear();
            // Create a new Combo control
            System.Windows.Forms.ComboBox comboMatch = new System.Windows.Forms.ComboBox();

            // Set the properties of the textbox
            comboMatch.Name = "comboMatch";

            comboMatch.Location = new Point(50, 50);
            comboMatch.Size = new Size(200, 50);
            comboMatch.SelectedIndexChanged += new EventHandler(comboMatch_SelectedIndexChanged);

            this.panel1.Controls.Add(comboMatch);

            //Membuat Pemain Unik
            List<string> listMatchUnik = new List<string>();
            foreach (DataRow row in dtMatch.Rows)
            {
                listMatchUnik.Add(row[0].ToString());

            }

            List<string> uniqueListMatch = listMatchUnik.Distinct().ToList();
            foreach (string item in uniqueListMatch)
            {
                comboMatch.Items.Add(item);
            }


        }

        private void comboBoxPemain_SelectedIndexChanged(object sender, EventArgs e)
        {
            System.Windows.Forms.ComboBox clickedCombo = (System.Windows.Forms.ComboBox)sender;
            //Cari Data
            String namaPemain = "", namaTeam = "", position = "";  ////Sini..........
            int jmlGoal = 0, jmlKartuKuning = 0, jmlKartuMerah = 0, jmlPinaltiMiss = 0 , jmlGoalPenalty = 0 , jmlOwnGoal = 0, jmlPenaltyMiss = 0;
            if (this.panel1.Controls.Count > 1)
            {

                this.panel1.Controls.RemoveAt(1);
                this.panel1.Controls.RemoveAt(1);
                this.panel1.Controls.RemoveAt(1);
            }

            foreach (DataRow row in dtPemain.Rows)
            {
                if (row[0].ToString() == clickedCombo.Text)
                {
                    namaPemain = row[0].ToString();
                    namaTeam = row[1].ToString();
                    //.........Sini..............
                    /*
                     * cy yellow card
                        cr red card
                        go goal
                        gp goal penalty
                        gw own goal
                        pm penalty miss
                     */
                    if (row[4].ToString() == "CY")
                    {
                        jmlKartuKuning++;
                    }
                    else if (row[4].ToString() == "CR")
                    {
                        jmlKartuMerah++;
                    }
                    else if (row[4].ToString() == "GO")
                    {
                        jmlGoal++;
                    }
                    else if (row[4].ToString() == "GP")
                    {
                        jmlGoalPenalty++;
                    }
                    else if (row[4].ToString() == "GW")
                    {
                        jmlOwnGoal++;
                    }
                    else if (row[4].ToString() == "PM")
                    {
                        jmlPenaltyMiss++;
                    }
                   
                }

            }


            // Create a new label Nama control//////////////////////
            Label lblNamaPemain = new Label();

            // Set the properties of the textbox
            lblNamaPemain.Name = "lblNamaPemain";
            lblNamaPemain.Text = "Player Name: " + namaPemain;
            lblNamaPemain.Location = new Point(50, 80);
            lblNamaPemain.Size = new Size(300, 50);
            lblNamaPemain.ForeColor = Color.Green;
            lblNamaPemain.Font = new Font("Arial", 8, FontStyle.Bold);



            this.panel1.Controls.Add(lblNamaPemain);

            // Create a new label Team control//////////////////////
            Label lblNamaTeam = new Label();

            // Set the properties of the textbox
            lblNamaTeam.Name = "lblNamaTeam";
            lblNamaTeam.Text = "Team Name: " + namaTeam;
            lblNamaTeam.Location = new Point(50, 130);
            lblNamaTeam.Size = new Size(300, 50);
            lblNamaTeam.ForeColor = Color.Green;
            lblNamaTeam.Font = new Font("Arial", 8, FontStyle.Bold);

            this.panel1.Controls.Add(lblNamaTeam);

            // Create a new label Team control//////////////////////
            Label lblStatus = new Label();

            // Set the properties of the textbox
            lblStatus.Name = "lblStatus";
            lblStatus.Text = "Status pemain:\nKartu Kuning = " + jmlKartuKuning.ToString() + " \nKartu Merah = " + jmlKartuMerah.ToString() + " \nGoal = " + jmlGoal.ToString() + " \nPenalty Goal = " + jmlGoalPenalty.ToString() + " \nOwn Goal = " + jmlOwnGoal.ToString() + " \nPenalty Miss = " + jmlGoalPenalty.ToString();
            lblStatus.Location = new Point(50, 180);
            lblStatus.Size = new Size(300, 100);
            lblStatus.ForeColor = Color.Red;
            lblStatus.Font = new Font("Arial", 8, FontStyle.Bold);

            this.panel1.Controls.Add(lblStatus);


        }

        private void comboMatch_SelectedIndexChanged(object sender, EventArgs e)
        {
            System.Windows.Forms.ComboBox clickedCombo = (System.Windows.Forms.ComboBox)sender;
            //Cari Data
            String dateMatch = "", teamHome = "", teamAway = "";
            int minutes = 0, jmlKartuKuning = 0, jmlKartuMerah = 0, jmlPinaltiMiss = 0;


            if (this.panel1.Controls.Count > 1)
            {
                this.panel1.Controls.RemoveAt(1);
                this.panel1.Controls.RemoveAt(1);

            }

            foreach (DataRow row in dtMatch.Rows)
            {
              
                if (row[0].ToString() == clickedCombo.Text)
                {
                    dateMatch = row[0].ToString();
                    minutes = int.Parse(row[1].ToString());
                    teamHome = row[3].ToString();
                    teamAway = row[4].ToString();
                }
            }

            // Create a new label Nama control//////////////////////
            Label lblMatchDate = new Label();

            // Set the properties of the textbox
            lblMatchDate.Name = "lblMatchDate";
            lblMatchDate.Text = "Match Date: " + dateMatch;
            lblMatchDate.Location = new Point(50, 100);
            lblMatchDate.Size = new Size(300, 50);
            lblMatchDate.ForeColor = Color.Green;
            lblMatchDate.Font = new Font("Arial", 8, FontStyle.Bold);

            this.panel1.Controls.Add(lblMatchDate);

            // Create a new label Nama control//////////////////////
            Label lblMinute = new Label();

            // Set the properties of the textbox
            lblMinute.Name = "lblMinutes";
            lblMinute.Text = "Long of the Match: " + minutes + " minutes";
            lblMinute.Location = new Point(50, 150);
            lblMinute.Size = new Size(300, 50);
            lblMinute.ForeColor = Color.Green;
            lblMinute.Font = new Font("Arial", 8, FontStyle.Bold);

            this.panel1.Controls.Add(lblMinute);

            Label lblHomeTeam = new Label();

            lblHomeTeam.Name = "lblHomeTeam";
            lblHomeTeam.Text = "Home Team: " + teamHome;
            lblHomeTeam.Location = new Point(50, 200);
            lblHomeTeam.Size = new Size(300, 50);
            lblHomeTeam.ForeColor = Color.Red;
            lblHomeTeam.Font = new Font("Arial", 8, FontStyle.Bold);

            this.panel1 .Controls.Add(lblHomeTeam);

            Label lblTeamAway = new Label();

            lblTeamAway.Name = "lblTeamAway";
            lblTeamAway.Text = "Team Away: " + teamAway;
            lblTeamAway.Location = new Point(50, 250);
            lblTeamAway.Size = new Size(300, 50);
            lblTeamAway.ForeColor = Color.Red;
            lblTeamAway.Font = new Font("Arial", 8, FontStyle.Bold);

            this.panel1.Controls.Add(lblTeamAway);


            ListBox listPlayerTeamHome = new ListBox();

            // Set the properties of the textbox
            listPlayerTeamHome.Name = "listPlayerTeamAway";
            listPlayerTeamHome.Location = new Point(50, 300);
            listPlayerTeamHome.Size = new Size(300, 300);
            listPlayerTeamHome.ForeColor = Color.Gold;
            listPlayerTeamHome.Font = new Font("Arial", 8, FontStyle.Bold);


            this.panel1.Controls.Add(listPlayerTeamHome);

            //Membuat Match Unik
            List<string> listMatchUnik = new List<string>();
            foreach (DataRow row in dtMatch.Rows)
            {

                if (row[3].ToString() == teamHome)
                {
                    listMatchUnik.Add(row[5].ToString());
                }
            }

            List<string> uniqueListPemain = listMatchUnik.Distinct().ToList();
            foreach (string item in uniqueListPemain)
            {
                listPlayerTeamHome.Items.Add(item);
            }


        }
    }
}
